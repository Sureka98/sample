package com.companyname.springbootcrudrest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.springbootcrudrest.exception.ResourceNotFoundException;
import com.companyname.springbootcrudrest.model.Company;
import com.companyname.springbootcrudrest.repository.CompanyRepository;

@RestController
@RequestMapping("/api/v2")

public class CompanyController {
	@Autowired
	private CompanyRepository companyRepository;

	
	@GetMapping("/company")
	public List<Company> getAllCompanies() {
		return companyRepository.findAll();
	}

	@GetMapping("/companies/{companyid}")
	public ResponseEntity<Company> getCompanyByIdEntity(
			@PathVariable(value = "companyid") Long companyid) throws ResourceNotFoundException {
		Company company = companyRepository.findBycompanyid(companyid)
        .orElseThrow(() -> new ResourceNotFoundException("company not found"));
		return ResponseEntity.ok().body(company);
	}

	@PostMapping("/company")
	public Company createcompany( @RequestBody Company company) {
		return companyRepository.save(company);
	}
	
   @PutMapping("/companies/{companyid}")
	public ResponseEntity<Company> updateCompany(
			@PathVariable(value = "companyid") Long companyid,
			@RequestBody Company companyDetails) throws ResourceNotFoundException {
	   Company company= companyRepository.findBycompanyid(companyid)
		        .orElseThrow(() -> new ResourceNotFoundException("company not found"));
		company.setCompanyid(companyDetails.getCompanyid());
		company.setCompanyName(companyDetails.getCompanyName());
		final Company updatedCompany = companyRepository.save(company);
		return ResponseEntity.ok(updatedCompany);
	}

	@DeleteMapping("/companies/{companyid}")
	public Map<String, Boolean> deleteCompany(
			@PathVariable(value = "companyid") Long companyid) throws ResourceNotFoundException {
		Company company = companyRepository.findBycompanyid(companyid)
		        .orElseThrow(() -> new ResourceNotFoundException("company not found"));

		companyRepository.delete(company);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
