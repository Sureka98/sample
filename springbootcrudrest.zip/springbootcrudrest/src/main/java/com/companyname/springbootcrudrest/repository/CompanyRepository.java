package com.companyname.springbootcrudrest.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.companyname.springbootcrudrest.model.Company;



public interface CompanyRepository extends JpaRepository<Company, Long>{

	

	Optional<Company> findBycompanyid(Long companyid);


}