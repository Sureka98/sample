package com.companyname.springbootcrudrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcrudrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
